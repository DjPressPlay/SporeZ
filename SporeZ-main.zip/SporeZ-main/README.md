# SporeZ
SPORZ  emergent identity Generator
